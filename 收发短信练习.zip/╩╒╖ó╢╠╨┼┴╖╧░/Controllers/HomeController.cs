﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using 收发短信练习.Models;

namespace 收发短信练习.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private Twilio twilio = new Twilio();
        public HomeController(ILogger<HomeController> logger,Twilio _twilio)
        {
            _logger = logger;
            this.twilio = _twilio;
        }

        public IActionResult Index()
        {
            return View();
        }

        public JsonResult Add(string tel, string what)
        {
            return Json(twilio.Add(tel, what));
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult ToEle()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
