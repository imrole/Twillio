﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Types;
using Twilio.Rest.Api.V2010.Account;

namespace 收发短信练习.Controllers
{
    public class Twilio
    {
        public string Add(string phone,string what)
        {
            try
            {

                // Find your Account Sid and Token at twilio.com/console
                // DANGER! This is insecure. See http://twil.io/secure
                string accountSid = "you-sid";
                string authToken = "you-token";

                TwilioClient.Init(accountSid, authToken);
                var message = MessageResource.Create(
                    body: what,
                    from: new PhoneNumber("you-number"),
                    to: new PhoneNumber("86"+phone)
                ) ;
                return message.Sid;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
